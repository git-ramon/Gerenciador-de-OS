<?php

function exibeImc($valorImc){
    if($valorImc <= 18.5){
        echo 'Abaixo do Peso';
    }elseif($valorImc <= 24.9){
        echo 'Peso Normal';
    }elseif($valorImc <= 29.9){
        echo 'Sobrebeso';
    }elseif($valorImc <= 34.9){
        echo 'Obesidade Grau I';
    }elseif($valorImc <= 39.9){
        echo 'Obesidade Grau II';
    }else{
        echo 'Obesidade Grau III ou Mórbida';
    }
}

//Inicialização das variáveis
$peso = 0;
$altura = 0;
$imc = 0;

//O if faz uma verificação utilizando a função array_key_exists. Verifica se o valor existe
//Só então atribui o valor à variável
if(array_key_exists('peso',$_GET)){
    $peso = $_GET['peso'];
}

if(array_key_exists('altura',$_GET)){
    $altura = $_GET['altura'];
}

if($peso > 0 && $altura > 0){
    $imc = $peso / ($altura * $altura);
}


?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Cálculo de Índice de Massa Corporal</title>
    </head>
    <body>
        <form method="GET" action="#">
            <fieldset>
                <legend>Cálculo IMC</legend>
                <label> Altura
                <input type="text" name="altura" pattern="^\d\.\d{2}$" required>
                </label>
                <label> Peso
                <input type="text" name="peso" required>
                </label>
                <input type="submit" value="Calcular">
            </fieldset>
        </form>
        <?php
            //Exibe o valor calculado. Utiliza a função Floor() para pegar a parte inteira do número.
            if($imc > 0){
            echo "Seu IMC é: " .floor($imc)."<br>";
                exibeImc($imc);
            }
        ?>
    </body>
</html>