<?php

    // Declaração de variáveis
    $variavel = "Texto de uma variável";
    $verifica = "";

    // Como verificar se uma variável foi definida
    if(isset($nome))
    $verifica = "A variável nome não foi setada";

    $nome = "Clark Kent"; //String
    $idade = 35; //Inteiro ou INT
    $preco = 12.9; //Float, Número de ponto flutuante
    $comprado = TRUE;//Booleano
    $lista = [1,2,34,56,100];//Array

    //Declaração de uma constante
    define("minhaConstante", "Valor Constante");

    //Operadores aritiméticos
    $valor1 = 2;
    $valor2 = 5;

    $soma = $valor1 + $valor2; //Soma
    $subtracao = $valor1 - $valor2; //Subtração
    $multiplica = $valor1 * $valor2; //Multiplicação
    $divide = $valor1 / $valor2; //Divisão
    $modulo = $valor2 % $valor1; //Módulo Retorna o resto da divisão

    $valor3 = 42.0;
    $valor4 = 45.0;

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Minha Página PHP</title>
    </head>
    <body>
        <h1>Título sem PHP</h1>
        <h2><?php echo minhaConstante; ?></h2>
        <h3>
        <?php echo "Hello World, meu primeiro código PHP.";?>
        </h3>
        <br>
        <form>
            <input type="text" value="
                <?php 
                    echo $variavel;
                ?>
            ">
        </form>
        <br>
        <table border="1">
            <tr>
                <td>Nome:</td>
                <td>Idade:</td>
            </tr>
            <tr>
                <td>
                    <?php
                    echo $nome;
                    ?>
                </td>
                <td>
                    <?php
                    echo $idade;
                    ?>
                </td>
            </tr>
        </table>
        <?php
            if(isset($nome)){
                echo "A variável nome agora é " .$nome;
            }else{
                echo $verifica;
            }
        ?>

        <ul>
            <li><?php echo "Soma: " .$soma; ?></li>
            <li><?php echo "Subtração: " .$subtracao; ?></li>
            <li><?php echo "Multiplicação: " .$multiplica; ?></li>
            <li><?php echo "Divisão: " .$divide; ?></li>
            <li><?php echo "Módulo: " .$modulo; ?></li>
        </ul>   

    
    </body>
</html>