<?php

$texto = 'Te';
$quantidadeLetras = strlen($texto); //Retorna a quantidade de Characteres
$posicaoCharacter = strpos('Meu nome','n'); //Retorna a posição de um valor procurado
$nome = "Leandro Gomides Lima";
$resultado = explode(' ',$nome); //Divide uma string separada por um determinado caracter
$senha = '123456';
$senhaArmazenada = md5($senha);
$nomeErrado = '   Bruno Gonçalvez da Silva         ';



switch ($quantidadeLetras) {
    case 0:
        echo 'Não há texto';
        break;
    case 1:
        echo 'Só tem uma letra';
        break;
    case 2:
        echo 'Tem duas letras';
        break;
    
    default:
        echo 'Tem 3 letras ou mais';
        break;
}

echo '<br> '.$posicaoCharacter;

echo '<br> '.$resultado[0];
echo '<br> '.$resultado[1];
echo '<br> '.$resultado[2];

echo '<br> '.strchr($nome, 'Li');// Imprime uma string a partir de um determinado valor;

if(md5('654321') === $senhaArmazenada){
    echo "Senha correta ";
}else{
    echo "Senha incorreta ";
}

echo md5($senha);

echo '<br> '.$nomeErrado;

echo '<br> '.trim($nomeErrado);

?>