<?php

//Criação de uma Função

function exibeTexto($texto){
    echo $texto;
}

// exibeTexto('Texto de exemplo');

function calculaImc($peso, $altura){
    $imc = $peso / ($altura * $altura);
    echo floor($imc);

    // return $imc; //Utilizar caso queira passar o resultado para ser tratado por outra função
}

calculaImc(78,1.87);

?>