<?php

//Declaração de um Array - Coleção(lista) de dados

// Uma forma de criar $meuPrimeiroArray = array('a','b','c','d','e');
$meuPrimeiroArray = ['a','b','c','d','e']; 

// echo $meuPrimeiroArray[2]; Exibe o valor da posição declarada

/* Usar o For para iterar o Array tem desvantagens
for($i=0;$i < 10; $i++){
    echo $meuPrimeiroArray[$i];
}
*/

//Sintax Foreach(Para cada), bem mais simples
foreach($meuPrimeiroArray as $valor){
    echo $valor .' ';
}
?>

<ul>
<?php
//Foreach para criar uma lista
foreach($meuPrimeiroArray as $valor){
    echo '<li>'.$valor.'</li>';
}?>
</ul>