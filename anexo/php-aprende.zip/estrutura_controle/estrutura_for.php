<?php

//Sintaxe For - Atenção especial para o incremento da variável
echo 'Sequencia crescente <br>';
for ($i=0; $i < 10; $i++) { 
    echo ($i+1) .' ';
}

//Atenção especial para o decremento da variável
echo '<br>Sequencia decrescente <br>';
for ($i=10; $i > 0; $i--){
    echo $i .' ';
}

//Como podemos fazer uma contagem indentificando se o número é par ou ímpar
echo '<br>Verifica se é Par ou Ímpar<br>';
for($i=0; $i < 10; $i++){
     $daVez = $i + 1;
     $numero = ($daVez) % 2;
     if($numero == 0){
         echo ($daVez).'é par<br>';
     }else{
        echo ($daVez).'é ímpar<br>';
     }
}



?>