<?php

//Estrutura Switch

$valor = 10;

switch ($valor) {
    case 20:
        echo 'O valor é 20';
        break;
    case 30:
        echo 'O valor é 30';
        break;
    default:
        echo 'Nenhum dos valores do Switch encontrado.';
        break;
}


?>