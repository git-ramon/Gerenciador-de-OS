<?php

$idade = 21;
$estado = "SP";
$numero = 0;

//Estrutura IF
if($idade >= 18){
    //código a ser executado
    echo "Você está liberado!";
}else{
    echo "Você precisa ter 18 anos.";
}

echo "<br>";

//Forma abreviada
if($numero == 0)
    echo "O número realmente é zero!";

echo "<br>";

if($estado == "RJ"){
    echo "Garota de Ipanema";
}elseif($estado == "SP"){
    echo "Terra da Garoa";
}else{
    echo "Brasileiro com muito orgulho";
}

echo "<br>";
/* Questão 1 - Crie um algorítimo que receba uma número e verifique se esse
número é positivo, negativo ou igual a zero. Exiba a menssagem correnpondente*/

if($numero > 0){
    echo "Número Positivo.";
}elseif($numero < 0){
    echo "Número Negativo.";
}else{
    echo "O número é zero.";
}

/* Questão 2 - Crie um Algorítimo que verifique se o valor de A é maior ou menor
que o valor da variável B. Exibir a mensagem "A maior que B" ou "A menor que B". */
$valorA = 10;
$valorB = 20;

if($valorA > $valorB){
    echo "A maior que B";
}else{
    echo "A menor que B";
}

?>